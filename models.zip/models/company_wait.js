import mongoose from 'mongoose';

const Company_wait = new mongoose.Schema({
    Name: String,
    Email: String,
    Mobile: Number,
    Address: String,
    Country: String,
    username: {
        type: String,
        unique: true,
    },
    password: String,
});

const company_wait = mongoose.model('tutors', Company_wait);
export default company_wait;